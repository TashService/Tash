ESX = nil

TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)

RegisterNetEvent("revivestation:attemptRevive", function(targetServerId, cost)
    local src = source
    local xPlayer = ESX.GetPlayerFromId(src)

    if xPlayer then
        if xPlayer.getMoney() >= cost then
            local targetPlayer = ESX.GetPlayerFromId(targetServerId)
            if targetPlayer then
                -- Charge money
                xPlayer.removeMoney(cost)

                -- Revive logic, using esx_ambulancejob's event (change if your revive logic is different)
                TriggerClientEvent('esx_ambulancejob:revive', targetServerId)

                -- Notify both
                TriggerClientEvent('revivestation:notify', src, "You have revived the player for $" .. cost)
                TriggerClientEvent('revivestation:notify', targetServerId, "You have been revived!")
            else
                TriggerClientEvent('revivestation:notify', src, "Target player is not online.")
            end
        else
            TriggerClientEvent('revivestation:notify', src, "You do not have enough money ($" .. cost .. ").")
        end
    end
end)
