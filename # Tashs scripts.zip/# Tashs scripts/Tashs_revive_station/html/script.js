window.addEventListener("message", (event) => {
    if (event.data.action === "open") {
        const list = document.getElementById("player-list");
        list.innerHTML = "";

        if (event.data.players.length === 0) {
            list.innerHTML = "<li>No dead players nearby.</li>";
        } else {
            event.data.players.forEach(player => {
                const li = document.createElement("li");
                li.textContent = `${player.name} (${player.serverId})`;
                li.onclick = () => {
                    fetch("https://revivestation/revivePlayer", {
                        method: "POST",
                        headers: { "Content-Type": "application/json" },
                        body: JSON.stringify({ serverId: player.serverId })
                    });
                    closeMenu();
                };
                list.appendChild(li);
            });
        }
        document.getElementById("menu").style.display = "block";
    } else if (event.data.action === "close") {
        document.getElementById("menu").style.display = "none";
    }
});

function closeMenu() {
    document.getElementById("menu").style.display = "none";
    fetch("https://revivestation/close", { method: "POST" });
}
