shared_script "@Adlerauge/anvil.lua"
fx_version 'cerulean'
game 'gta5'

author 'Tash'
description 'Revive Station with Auto-nearest revive and cost'
version '1.0.0'

client_script 'client.lua'
server_script 'server.lua'