local reviveStation = {
    coords = vector4(294.5432, -596.1810, 43.2687, 73.2753), -- x,y,z,heading
    pedModel = "s_m_m_doctor_01",
    interactDistance = 2.0,
    reviveCost = 5000
}

local ESX = nil

-- Get ESX object
Citizen.CreateThread(function()
    while ESX == nil do
        TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)
        Citizen.Wait(0)
    end
end)

-- Load and spawn NPC
function loadModel(model)
    RequestModel(model)
    while not HasModelLoaded(model) do Wait(0) end
end

Citizen.CreateThread(function()
    loadModel(reviveStation.pedModel)
    local ped = CreatePed(4, GetHashKey(reviveStation.pedModel),
        reviveStation.coords.x, reviveStation.coords.y, reviveStation.coords.z - 1,
        reviveStation.coords.w, false, true)

    FreezeEntityPosition(ped, true)
    SetEntityInvincible(ped, true)
    SetBlockingOfNonTemporaryEvents(ped, true)
end)

-- Interaction loop
Citizen.CreateThread(function()
    while true do
        local playerPed = PlayerPedId()
        local coords = GetEntityCoords(playerPed)
        local dist = #(coords - vector3(reviveStation.coords.x, reviveStation.coords.y, reviveStation.coords.z))

        if dist < reviveStation.interactDistance then
            DrawText3D(reviveStation.coords.x, reviveStation.coords.y, reviveStation.coords.z + 1.0, "[E] Person Wiederbeleben ($"..reviveStation.reviveCost..")")
            if IsControlJustPressed(0, 38) then -- E
                tryReviveNearestPlayer()
            end
        end

        Citizen.Wait(0)
    end
end)

function tryReviveNearestPlayer()
    local playerPed = PlayerPedId()
    local playerCoords = GetEntityCoords(playerPed)

    local nearestPlayer = nil
    local nearestDistance = 999.0

    for _, playerId in ipairs(GetActivePlayers()) do
        local targetPed = GetPlayerPed(playerId)
        if IsEntityDead(targetPed) then
            local targetCoords = GetEntityCoords(targetPed)
            local dist = #(playerCoords - targetCoords)
            if dist < nearestDistance and dist < 10.0 then
                nearestPlayer = playerId
                nearestDistance = dist
            end
        end
    end

    if nearestPlayer then
        local serverId = GetPlayerServerId(nearestPlayer)
        TriggerServerEvent("revivestation:attemptRevive", serverId, reviveStation.reviveCost)
    else
        notify("No dead players nearby to revive.")
    end
end

-- Notification helper
function notify(msg)
    SetNotificationTextEntry("STRING")
    AddTextComponentString(msg)
    DrawNotification(false, false)
end

-- 3D text helper
function DrawText3D(x, y, z, text)
    local onScreen, _x, _y = World3dToScreen2d(x, y, z)
    if onScreen then
        SetTextScale(0.35, 0.35)
        SetTextFont(4)
        SetTextProportional(1)
        SetTextColour(255, 255, 255, 215)
        SetTextCentre(true)
        SetTextEntry("STRING")
        AddTextComponentString(text)
        DrawText(_x, _y)
    end
end

-- Receive revive event from server
RegisterNetEvent("revivestation:doRevive", function()
    local ped = PlayerPedId()
    DoScreenFadeOut(500)
    Citizen.Wait(1000)
    ResurrectPed(ped)
    SetEntityHealth(ped, 200)
    ClearPedTasksImmediately(ped)
    DoScreenFadeIn(500)
end)

-- Notify on failure
RegisterNetEvent("revivestation:notify", function(message)
    notify(message)
end)
