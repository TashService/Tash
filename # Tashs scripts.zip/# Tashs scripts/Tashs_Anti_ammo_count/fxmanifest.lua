shared_script "@Adlerauge/anvil.lua"
fx_version 'cerulean'
game 'gta5'

author 'Tash'
description 'Anti Standard GTAV ammo Overlay'
version '1.2.0'

client_scripts {
  'client.lua'}