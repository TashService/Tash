shared_script "@Adlerauge/anvil.lua"
fx_version 'cerulean'
game 'gta5'

author 'Tash'
description 'Aduty System mit NUI, Maske, Godmode, Nametag und Player-ID'
version '1.2.0'

client_scripts {
  'config.lua',
  'client.lua'
}

server_scripts {
  'config.lua',
  'server.lua'
}

ui_page 'html/index.html'

files {
  'html/index.html',
  'html/style.css',
  'html/script.js'
}