local savedSkin, adutyPlayers = nil, {}
local onDuty = false

-- NUI
function notifyNUI(msg, duration)
  SendNUIMessage({action='notify', message=msg, time=duration or 3000})
end

-- Dienst aktivieren
RegisterNetEvent('aduty:enable', function(role)
  local ped = PlayerPedId()
  TriggerEvent('skinchanger:getSkin', function(skin) savedSkin = skin end)

  local gender = GetEntityModel(ped)==GetHashKey('mp_m_freemode_01') and 'male' or 'female'
  local outfit = Config.Outfits[role] and Config.Outfits[role][gender]; if not outfit then return end

  SetPedComponentVariation(ped,8, outfit.tshirt_1, outfit.tshirt_2)
  SetPedComponentVariation(ped,11, outfit.torso_1, outfit.torso_2)
  SetPedComponentVariation(ped,4, outfit.pants_1, outfit.pants_2)
  SetPedComponentVariation(ped,6, outfit.shoes_1, outfit.shoes_2)
  if outfit.mask_1 then SetPedComponentVariation(ped,1,outfit.mask_1,outfit.mask_2,2) end

  onDuty = true
  SetPlayerInvincible(PlayerId(), true)
 -- notifyNUI('~g~Aduty aktiviert',3000)
end)

-- Dienst beenden
RegisterNetEvent('aduty:disable', function()
  if savedSkin then
    TriggerEvent('skinchanger:loadSkin', savedSkin)
    savedSkin = nil
  end

  onDuty = false
  SetPlayerInvincible(PlayerId(), false)
 -- notifyNUI('~r~Aduty deaktiviert',3000)
end)

-- Nametags sync
RegisterNetEvent('aduty:updateTags', function(tbl)
  adutyPlayers = tbl or {}
end)

-- Nametag zeichnen
Citizen.CreateThread(function()
  while true do
    Wait(0)
    if Config.ShowNametags then
      for id, role in pairs(adutyPlayers) do
        local pid = GetPlayerFromServerId(tonumber(id))
        if pid ~= -1 and pid ~= PlayerId() then
          local ped = GetPlayerPed(pid)
          local coords = GetEntityCoords(ped)
          if #(coords - GetEntityCoords(PlayerPedId())) < 25.0 then
            DrawText3D(coords.x,coords.y,coords.z+1.1, role..' ['..id..']')
          end
        end
      end
    end
  end
end)

-- 3D-Text
function DrawText3D(x,y,z,text)
  SetTextScale(0.35,0.35); SetTextFont(4); SetTextProportional(1)
  SetTextColour(255,0,0,200); SetTextOutline()
  SetTextEntry('STRING'); AddTextComponentString(text)
  SetDrawOrigin(x,y,z,0); DrawText(0.0,0.0)
  local factor = (string.len(text))/370 + 0.015
  DrawRect(0.0,0.0125,factor,0.03,0,0,0,80)
  ClearDrawOrigin()
end
