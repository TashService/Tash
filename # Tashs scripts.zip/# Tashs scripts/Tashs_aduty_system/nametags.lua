local showNametag = false
local adminRole = ""

RegisterNetEvent("aduty:nametagEnable", function(role)
    showNametag = true
    adminRole = role
end)

RegisterNetEvent("aduty:nametagDisable", function()
    showNametag = false
    adminRole = ""
end)

Citizen.CreateThread(function()
    while true do
        Citizen.Wait(0)
        if showNametag then
            local ped = PlayerPedId()
            local coords = GetEntityCoords(ped)
            DrawText3D(coords.x, coords.y, coords.z + 1.0, adminRole)
        end
    end
end)

function DrawText3D(x, y, z, text)
    local onScreen, _x, _y = World3dToScreen2d(x, y, z)
    local camCoords = GetGameplayCamCoords()
    local dist = #(camCoords - vector3(x, y, z))

    if onScreen then
        local scale = (1.0 / dist) * 2.0
        scale = scale * (1.0 / GetGameplayCamFov()) * 100

        SetTextScale(0.35, 0.35)
        SetTextFont(4)
        SetTextProportional(1)
        SetTextColour(255, 0, 0, 215)
        SetTextOutline()
        SetTextEntry("STRING")
        AddTextComponentString(text)
        DrawText(_x, _y)
    end
end
