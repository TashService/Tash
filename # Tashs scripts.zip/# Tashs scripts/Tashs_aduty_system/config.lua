Config = {}

-- Nametags aktivieren (true/false)
Config.ShowNametags = true

-- Identifiers (Steam, Discord, License usw.) und Rollen
Config.AdminIdentifiers = {
    ["discord:933803492282351626"] = "Owner",
    ["discord:123456789012345678"] = "Projektleitung",
    ["license:abcdef1234567890"] = "Admin",
    ["steam:110000112345679"] = "Mod",
    ["discord:876543210987654321"] = "Support"
}

-- Kleidung f�r Rollen und Geschlecht
Config.Outfits = {
    ["Owner"] = {
        male = {
            tshirt_1 = 15, tshirt_2 = 0,
            torso_1 = 287, torso_2 = 6,
            pants_1 = 114, pants_2 = 6,
            shoes_1 = 42, shoes_2 = 0,
            mask_1 = 135, mask_2 = 6
        },
        female = {
            tshirt_1 = 14, tshirt_2 = 0,
            torso_1 = 303, torso_2 = 0,
            pants_1 = 37, pants_2 = 0,
            shoes_1 = 52, shoes_2 = 0,
	    mask_1 = 1, mask_2 = 1
        }
    },
    ["Projektleitung"] = {
        male = {
            tshirt_1 = 15, tshirt_2 = 0,
            torso_1 = 287, torso_2 = 2,
            pants_1 = 114, pants_2 = 2,
            shoes_1 = 73, shoes_2 = 17,
            mask_1 = 135, mask_2 = 2
        },
        female = {
            tshirt_1 = 14, tshirt_2 = 0,
            torso_1 = 303, torso_2 = 0,
            pants_1 = 37, pants_2 = 0,
            shoes_1 = 52, shoes_2 = 0,
	    mask_1 = 1, mask_2 = 1
        }
    },
    ["Admin"] = {
        male = {
            tshirt_1 = 15, tshirt_2 = 0,
            torso_1 = 13, torso_2 = 0,
            pants_1 = 25, pants_2 = 0,
            shoes_1 = 21, shoes_2 = 0,
            helmet_1 = -1, helmet_2 = 0
        },
        female = {
            tshirt_1 = 2, tshirt_2 = 0,
            torso_1 = 4, torso_2 = 0,
            pants_1 = 6, pants_2 = 0,
            shoes_1 = 35, shoes_2 = 0,
            helmet_1 = -1, helmet_2 = 0
        }
    },
    ["Mod"] = {
        male = {
            tshirt_1 = 15, tshirt_2 = 0,
            torso_1 = 27, torso_2 = 0,
            pants_1 = 21, pants_2 = 0,
            shoes_1 = 11, shoes_2 = 0,
            helmet_1 = -1, helmet_2 = 0
        },
        female = {
            tshirt_1 = 3, tshirt_2 = 0,
            torso_1 = 20, torso_2 = 0,
            pants_1 = 3, pants_2 = 0,
            shoes_1 = 33, shoes_2 = 0,
            helmet_1 = -1, helmet_2 = 0
        }
    },
    ["Support"] = {
        male = {
            tshirt_1 = 15, tshirt_2 = 0,
            torso_1 = 18, torso_2 = 0,
            pants_1 = 10, pants_2 = 0,
            shoes_1 = 12, shoes_2 = 0,
            helmet_1 = -1, helmet_2 = 0
        },
        female = {
            tshirt_1 = 3, tshirt_2 = 0,
            torso_1 = 3, torso_2 = 0,
            pants_1 = 2, pants_2 = 0,
            shoes_1 = 28, shoes_2 = 0,
            helmet_1 = -1, helmet_2 = 0
        }
    }
}
