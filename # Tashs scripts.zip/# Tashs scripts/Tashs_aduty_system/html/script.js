window.addEventListener('message', e=>{
  if(e.data.action==='notify'){
    const b=document.getElementById('notification')
    b.textContent=e.data.message
    b.classList.remove('hide');b.classList.add('show')
    setTimeout(()=>{b.classList.remove('show');b.classList.add('hide')},e.data.time||3000)
  }
})
