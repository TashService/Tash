local duty = {}

RegisterCommand('aduty', function(src)
    local ids = GetPlayerIdentifiers(src)
    local role = nil
    for _, id in ipairs(ids) do
        role = Config.AdminIdentifiers[id]
        if role then break end
    end

    if not role then
        TriggerClientEvent('chat:addMessage', src, { args = {'^1SYSTEM', 'Keine Berechtigung.'} })
        return
    end

    if duty[src] then
        duty[src] = nil
        TriggerClientEvent('aduty:disable', src)
    else
        duty[src] = role
        TriggerClientEvent('aduty:enable', src, role)
    end

    TriggerClientEvent('aduty:updateTags', -1, duty)
end)

AddEventHandler('playerDropped', function()
    local src = source
    duty[src] = nil
    TriggerClientEvent('aduty:updateTags', -1, duty)
end)
